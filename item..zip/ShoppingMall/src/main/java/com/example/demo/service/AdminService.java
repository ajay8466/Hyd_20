package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Admin;

public interface AdminService {

	public Admin saveAdmin(Admin admin);

 public Admin fetchAdminById(Long adminId);

public List<Admin> fetchAdminList();

public void deleteAdminById(Long adminId);

public Admin updateAdmin(Long id, Admin admin);
}

